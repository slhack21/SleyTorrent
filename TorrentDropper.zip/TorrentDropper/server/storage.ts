import { torrents, type Torrent, type InsertTorrent } from "@shared/schema";
import { nanoid } from "nanoid";
import type { ProcessingInfo, ProcessingStatus } from "@shared/schema";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Torrent methods
  getTorrent(id: number): Promise<Torrent | undefined>;
  getTorrentByHash(hash: string): Promise<Torrent | undefined>;
  getAllTorrents(): Promise<Torrent[]>;
  createTorrent(torrent: InsertTorrent): Promise<Torrent>;
  deleteTorrent(id: number): Promise<boolean>;
  
  // Processing methods
  getProcessingInfo(id: string): Promise<ProcessingInfo | undefined>;
  updateProcessingInfo(info: ProcessingInfo): Promise<ProcessingInfo>;
  deleteProcessingInfo(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private torrents: Map<number, Torrent>;
  private processingJobs: Map<string, ProcessingInfo>;
  currentUserId: number;
  currentTorrentId: number;

  constructor() {
    this.users = new Map();
    this.torrents = new Map();
    this.processingJobs = new Map();
    this.currentUserId = 1;
    this.currentTorrentId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  async getTorrent(id: number): Promise<Torrent | undefined> {
    return this.torrents.get(id);
  }
  
  async getTorrentByHash(hash: string): Promise<Torrent | undefined> {
    return Array.from(this.torrents.values()).find(
      (torrent) => torrent.hash === hash
    );
  }
  
  async getAllTorrents(): Promise<Torrent[]> {
    return Array.from(this.torrents.values()).sort((a, b) => {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
  }
  
  async createTorrent(insertTorrent: InsertTorrent): Promise<Torrent> {
    const id = this.currentTorrentId++;
    const createdAt = new Date();
    const torrent: Torrent = { ...insertTorrent, id, createdAt };
    this.torrents.set(id, torrent);
    return torrent;
  }
  
  async deleteTorrent(id: number): Promise<boolean> {
    return this.torrents.delete(id);
  }
  
  async getProcessingInfo(id: string): Promise<ProcessingInfo | undefined> {
    return this.processingJobs.get(id);
  }
  
  async updateProcessingInfo(info: ProcessingInfo): Promise<ProcessingInfo> {
    this.processingJobs.set(info.id, info);
    return info;
  }
  
  async deleteProcessingInfo(id: string): Promise<boolean> {
    return this.processingJobs.delete(id);
  }
}

// Import these from originally missing import
import { users, type User, type InsertUser } from "@shared/schema";

export const storage = new MemStorage();
