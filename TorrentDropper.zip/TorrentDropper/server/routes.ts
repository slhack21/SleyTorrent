import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { magnetLinkSchema } from "@shared/schema";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";
import { nanoid } from "nanoid";
import * as path from "path";
import * as fs from "fs";
import * as util from "util";
import { fileURLToPath } from "url";
// We're no longer using WebSockets
import { promisify } from "util";
import * as crypto from "crypto";
import archiver from "archiver";

// For ESM
import parseTorrent from "parse-torrent";
import WebTorrent from "webtorrent";
import { pipeline as streamPipeline } from "stream";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const pipeline = promisify(streamPipeline);
const client = new WebTorrent();

// Storage directory for processed files
const STORAGE_DIR = path.join(__dirname, "..", "storage");
const MAX_FILE_AGE_MS = 24 * 60 * 60 * 1000; // 24 hours

// Create storage directory if it doesn't exist
if (!fs.existsSync(STORAGE_DIR)) {
  fs.mkdirSync(STORAGE_DIR, { recursive: true });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Create HTTP server
  const httpServer = createServer(app);
  
  // We'll use a simple in-memory event emitter instead of WebSockets to avoid conflicts with Vite
  // This will store processing updates that can be polled via the API
  const processingUpdates = new Map<string, any>();
  
  // Update function for processing status
  function broadcastProgress(processingId: string, data: any) {
    processingUpdates.set(processingId, {
      ...data,
      timestamp: Date.now()
    });
    console.log(`Progress update for ${processingId}:`, data);
  }
  
  // Clean up old files
  cleanupOldFiles();
  
  // API Routes
  app.post("/api/magnet", async (req: Request, res: Response) => {
    try {
      // Validate the request body
      const result = magnetLinkSchema.safeParse(req.body);
      
      if (!result.success) {
        const validationError = fromZodError(result.error);
        return res.status(400).json({
          message: "Invalid request",
          errors: validationError.message
        });
      }
      
      const { magnetLink, includeMetadata, optimizeSize } = result.data;
      
      try {
        // Parse the magnet link to get torrent info
        const parsedTorrent = await parseTorrent(magnetLink);
        
        if (!parsedTorrent || !parsedTorrent.infoHash) {
          return res.status(400).json({
            message: "Invalid magnet link",
            error: "Could not parse the magnet link"
          });
        }
        
        // Generate a unique ID for the processing job
        const processingId = nanoid();
        
        // Set initial processing state
        await storage.updateProcessingInfo({
          id: processingId,
          status: "queued",
          progress: 0
        });
        
        // Start processing in the background
        processTorrent(processingId, magnetLink, parsedTorrent, includeMetadata, optimizeSize, broadcastProgress);
        
        // Return the processing ID to the client
        return res.status(202).json({
          processingId,
          message: "Processing started"
        });
        
      } catch (error: unknown) {
        console.error("Error parsing magnet link:", error);
        return res.status(400).json({
          message: "Invalid magnet link",
          error: error instanceof Error ? error.message : String(error)
        });
      }
    } catch (error: unknown) {
      console.error("Error processing magnet link:", error);
      return res.status(500).json({
        message: "Server error",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  app.get("/api/torrents", async (req: Request, res: Response) => {
    try {
      const torrents = await storage.getAllTorrents();
      return res.json(torrents);
    } catch (error: unknown) {
      console.error("Error fetching torrents:", error);
      return res.status(500).json({
        message: "Server error",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  app.get("/api/torrents/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        return res.status(400).json({
          message: "Invalid torrent ID"
        });
      }
      
      const torrent = await storage.getTorrent(id);
      if (!torrent) {
        return res.status(404).json({
          message: "Torrent not found"
        });
      }
      
      return res.json(torrent);
    } catch (error: unknown) {
      console.error("Error fetching torrent:", error);
      return res.status(500).json({
        message: "Server error",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  app.delete("/api/torrents/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        return res.status(400).json({
          message: "Invalid torrent ID"
        });
      }
      
      const torrent = await storage.getTorrent(id);
      if (!torrent) {
        return res.status(404).json({
          message: "Torrent not found"
        });
      }
      
      // Delete the ZIP file
      if (torrent.zipPath && fs.existsSync(torrent.zipPath)) {
        fs.unlinkSync(torrent.zipPath);
      }
      
      // Delete the torrent from storage
      await storage.deleteTorrent(id);
      
      return res.json({
        message: "Torrent deleted successfully"
      });
    } catch (error: unknown) {
      console.error("Error deleting torrent:", error);
      return res.status(500).json({
        message: "Server error",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  app.get("/api/processing/:id", async (req: Request, res: Response) => {
    try {
      const processingId = req.params.id;
      const processingInfo = await storage.getProcessingInfo(processingId);
      
      if (!processingInfo) {
        return res.status(404).json({
          message: "Processing job not found"
        });
      }
      
      return res.json(processingInfo);
    } catch (error: unknown) {
      console.error("Error fetching processing info:", error);
      return res.status(500).json({
        message: "Server error",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  app.get("/api/download/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        return res.status(400).json({
          message: "Invalid torrent ID"
        });
      }
      
      const torrent = await storage.getTorrent(id);
      if (!torrent) {
        return res.status(404).json({
          message: "Torrent not found"
        });
      }
      
      if (!torrent.zipPath || !fs.existsSync(torrent.zipPath)) {
        return res.status(404).json({
          message: "Zip file not found"
        });
      }
      
      // Send the zip file
      const filename = path.basename(torrent.zipPath);
      res.setHeader("Content-Type", "application/zip");
      res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
      
      const fileStream = fs.createReadStream(torrent.zipPath);
      fileStream.pipe(res);
    } catch (error: unknown) {
      console.error("Error downloading zip:", error);
      return res.status(500).json({
        message: "Server error",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // Helper function to process a torrent
  async function processTorrent(
    processingId: string, 
    magnetLink: string,
    parsedTorrent: any,
    includeMetadata: boolean,
    optimizeSize: boolean,
    broadcastFn: (id: string, data: any) => void
  ) {
    try {
      // Update status to downloading
      await storage.updateProcessingInfo({
        id: processingId,
        status: "downloading",
        progress: 0
      });
      
      broadcastFn(processingId, {
        status: "downloading",
        progress: 0,
        message: "Starting download..."
      });
      
      const torrentName = parsedTorrent.name || `torrent-${parsedTorrent.infoHash}`;
      const torrentHash = parsedTorrent.infoHash;
      
      // Check if we already have this torrent
      const existingTorrent = await storage.getTorrentByHash(torrentHash);
      if (existingTorrent && existingTorrent.zipPath && fs.existsSync(existingTorrent.zipPath)) {
        // Update the processing info with the existing torrent
        await storage.updateProcessingInfo({
          id: processingId,
          status: "completed",
          progress: 100,
          torrent: existingTorrent
        });
        
        broadcastFn(processingId, {
          status: "completed",
          progress: 100,
          torrent: existingTorrent,
          message: "Torrent already processed"
        });
        
        return;
      }
      
      // Create a temporary directory for the torrent
      const tempDir = path.join(STORAGE_DIR, `temp-${processingId}`);
      if (!fs.existsSync(tempDir)) {
        fs.mkdirSync(tempDir, { recursive: true });
      }
      
      // Download the torrent
      const torrent = client.add(magnetLink, { path: tempDir });
      
      // Track the download progress
      let lastProgress = 0;
      const progressInterval = setInterval(() => {
        const progress = Math.round(torrent.progress * 100);
        
        if (progress !== lastProgress) {
          lastProgress = progress;
          
          storage.updateProcessingInfo({
            id: processingId,
            status: "downloading",
            progress
          });
          
          broadcastFn(processingId, {
            status: "downloading",
            progress,
            message: `Downloading: ${progress}%`
          });
        }
      }, 1000);
      
      // Wait for the torrent to finish downloading
      await new Promise<void>((resolve, reject) => {
        torrent.on("done", () => {
          clearInterval(progressInterval);
          resolve();
        });
        
        torrent.on("error", (err: any) => {
          clearInterval(progressInterval);
          reject(err);
        });
      });
      
      // Update status to processing
      await storage.updateProcessingInfo({
        id: processingId,
        status: "processing",
        progress: 0
      });
      
      broadcastFn(processingId, {
        status: "processing",
        progress: 0,
        message: "Creating zip file..."
      });
      
      // Create the zip file
      const zipFilename = `${torrentName.replace(/[^a-z0-9]/gi, "_")}.zip`;
      const zipPath = path.join(STORAGE_DIR, zipFilename);
      
      // Create the zip
      const output = fs.createWriteStream(zipPath);
      const archive = archiver("zip", {
        zlib: { level: optimizeSize ? 9 : 1 }
      });
      
      archive.pipe(output);
      
      // Add the downloaded files to the archive
      archive.directory(tempDir, torrentName);
      
      // Add metadata if requested
      if (includeMetadata) {
        const metadataContent = JSON.stringify(parsedTorrent, null, 2);
        archive.append(metadataContent, { name: `${torrentName}/metadata.json` });
      }
      
      // Finalize the archive
      await archive.finalize();
      
      // Wait for the output stream to finish
      await new Promise<void>((resolve, reject) => {
        output.on("close", resolve);
        output.on("error", reject);
      });
      
      // Calculate the size of the zip file
      const stats = fs.statSync(zipPath);
      const sizeInBytes = stats.size;
      const size = formatFileSize(sizeInBytes);
      
      // Create a torrent record
      const insertTorrent = {
        name: torrentName,
        hash: torrentHash,
        magnetLink,
        size,
        zipPath,
        includeMetadata,
        optimizeSize
      };
      
      const savedTorrent = await storage.createTorrent(insertTorrent);
      
      // Update the processing info
      await storage.updateProcessingInfo({
        id: processingId,
        status: "completed",
        progress: 100,
        torrent: savedTorrent
      });
      
      broadcastFn(processingId, {
        status: "completed",
        progress: 100,
        torrent: savedTorrent,
        message: "Processing complete"
      });
      
      // Clean up the temporary directory
      fs.rmSync(tempDir, { recursive: true, force: true });
      
      // Remove the torrent from the client
      client.remove(torrent);
      
    } catch (error) {
      console.error("Error processing torrent:", error);
      
      // Update the processing info with the error
      await storage.updateProcessingInfo({
        id: processingId,
        status: "error",
        progress: 0,
        error: error.message
      });
      
      broadcastFn(processingId, {
        status: "error",
        progress: 0,
        error: error.message,
        message: "Error processing torrent"
      });
    }
  }
  
  // Helper function to clean up old files
  function cleanupOldFiles() {
    try {
      const files = fs.readdirSync(STORAGE_DIR);
      const now = new Date().getTime();
      
      for (const file of files) {
        if (file.startsWith("temp-")) {
          // Remove any temporary directories
          const dirPath = path.join(STORAGE_DIR, file);
          if (fs.statSync(dirPath).isDirectory()) {
            fs.rmSync(dirPath, { recursive: true, force: true });
          }
          continue;
        }
        
        const filePath = path.join(STORAGE_DIR, file);
        const stats = fs.statSync(filePath);
        
        // If the file is older than MAX_FILE_AGE_MS, delete it
        if (now - stats.mtimeMs > MAX_FILE_AGE_MS) {
          fs.unlinkSync(filePath);
        }
      }
    } catch (error) {
      console.error("Error cleaning up old files:", error);
    }
  }
  
  // Helper function to format file size
  function formatFileSize(bytes: number): string {
    if (bytes < 1024) return bytes + " B";
    const units = ["KB", "MB", "GB", "TB"];
    let value = bytes;
    let unitIndex = -1;
    
    while (value >= 1024 && unitIndex < units.length - 1) {
      value /= 1024;
      unitIndex++;
    }
    
    return value.toFixed(2) + " " + units[unitIndex];
  }
  
  return httpServer;
}
