import { useEffect, useState } from 'react';
import { auth } from './firebase';
import { signOut, onAuthStateChanged, User } from 'firebase/auth';
import { useNavigate } from 'react-router-dom';

export default function Home() {
  const [user, setUser] = useState<User | null>(null);
  const [magnet, setMagnet] = useState('');
  const [status, setStatus] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
      } else {
        navigate('/login');
      }
    });

    return () => unsubscribe();
  }, [navigate]);

  const handleLogout = async () => {
    await signOut(auth);
    navigate('/login');
  };

  const handleConvert = async () => {
    if (!magnet) {
      alert("Merci de coller un lien magnet.");
      return;
    }

    setStatus("Téléchargement et conversion en cours...");

    try {
      const res = await fetch("/download", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ magnet }),
      });

      if (!res.ok) throw new Error("Erreur serveur");

      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "torrent.zip";
      a.click();

      setStatus("Fichier prêt et téléchargé !");
    } catch (err: any) {
      setStatus("Erreur : " + err.message);
    }
  };

  return (
    <div style={{ maxWidth: 600, margin: 'auto', padding: '2rem', textAlign: 'center' }}>
      <h1>Bienvenue sur TorrentDropper</h1>
      {user && <p>Connecté en tant que : <strong>{user.email}</strong></p>}

      <input
        type="text"
        placeholder="Collez un lien magnet ici"
        value={magnet}
        onChange={(e) => setMagnet(e.target.value)}
        style={{
          width: '100%',
          padding: '10px',
          marginTop: '2rem',
          marginBottom: '1rem',
          borderRadius: '4px',
          border: '1px solid #ccc',
        }}
      />
      <br />
      <button
        onClick={handleConvert}
        style={{
          padding: '10px 20px',
          backgroundColor: '#2d8eff',
          color: 'white',
          border: 'none',
          borderRadius: '5px',
        }}
      >
        Télécharger & ZIP
      </button>

      <p style={{ marginTop: '1rem', color: '#555' }}>{status}</p>

      <hr style={{ margin: '2rem 0' }} />

      <button
        onClick={handleLogout}
        style={{
          padding: '10px 20px',
          backgroundColor: '#ef4444',
          color: 'white',
          border: 'none',
          borderRadius: '5px',
        }}
      >
        Se déconnecter
      </button>
    </div>
  );
}