import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import { DownloadIcon, Trash2, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { API } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import type { Torrent } from "@shared/schema";
import { Separator } from "@/components/ui/separator";

const DownloadsList: React.FC = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: torrents = [], isLoading, error } = useQuery({
    queryKey: ["/api/torrents"],
    staleTime: 1000 * 60, // 1 minute
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => API.deleteTorrent(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/torrents"] });
      toast({
        title: "Torrent deleted",
        description: "The torrent has been deleted successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete torrent: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const handleDeleteTorrent = (id: number) => {
    deleteMutation.mutate(id);
  };

  const handleDownload = (id: number) => {
    window.location.href = API.getDownloadUrl(id);
  };

  const handleSwitchToUploadTab = () => {
    // This would be handled by the parent component
  };

  const formatDate = (date: Date) => {
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - new Date(date).getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return "Just now";
    if (diffInMinutes < 60) return `${diffInMinutes} minute${diffInMinutes === 1 ? '' : 's'} ago`;
    
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) return `${diffInHours} hour${diffInHours === 1 ? '' : 's'} ago`;
    
    return format(new Date(date), "MMM d, yyyy");
  };

  if (isLoading) {
    return (
      <div className="p-6">
        <h3 className="text-lg font-medium mb-4">Recent Downloads</h3>
        <div className="flex items-center justify-center h-40">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6">
        <h3 className="text-lg font-medium mb-4">Recent Downloads</h3>
        <div className="text-center py-10">
          <p className="text-red-500">Error loading downloads</p>
          <Button variant="link" className="mt-2" onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/torrents"] })}>
            Try again
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <h3 className="text-lg font-medium mb-4">Recent Downloads</h3>
      
      {torrents.length === 0 ? (
        <div className="text-center py-10">
          <DownloadIcon className="h-16 w-16 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500">No downloads yet</p>
          <Button 
            variant="link" 
            className="mt-4 text-primary hover:text-blue-700 font-medium"
            onClick={handleSwitchToUploadTab}
          >
            Upload a magnet link
          </Button>
        </div>
      ) : (
        <div className="space-y-4">
          {torrents.map((torrent: Torrent) => (
            <div key={torrent.id} className="border border-gray-200 rounded-lg p-4">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex-1">
                  <h4 className="font-medium text-lg truncate">{torrent.name}</h4>
                  <div className="flex items-center text-sm text-gray-500 mt-1">
                    <span>{torrent.size}</span>
                    <Separator orientation="vertical" className="h-4 mx-2" />
                    <span className="flex items-center">
                      <Clock className="mr-1 h-3 w-3" />
                      <span>{formatDate(new Date(torrent.createdAt))}</span>
                    </span>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <Button
                    variant="default"
                    className="bg-green-600 hover:bg-green-700"
                    onClick={() => handleDownload(torrent.id)}
                  >
                    <DownloadIcon className="mr-2 h-4 w-4" /> Download
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => handleDeleteTorrent(torrent.id)}
                    disabled={deleteMutation.isPending}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default DownloadsList;
