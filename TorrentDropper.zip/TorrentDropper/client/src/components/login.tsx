import { useState } from 'react';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { auth } from './firebase';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = async () => {
    try {
      await signInWithEmailAndPassword(auth, email, password);
      alert("Connexion réussie !");
      window.location.href = "/"; // Redirection vers la page principale
    } catch (error) {
      alert("Erreur de connexion.");
      console.error(error);
    }
  };

  return (
    <div style={{ maxWidth: 400, margin: 'auto', paddingTop: '100px' }}>
      <h2>Connexion</h2>
      <input
        type="email"
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        style={{ width: '100%', marginBottom: 10 }}
      />
      <input
        type="password"
        placeholder="Mot de passe"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        style={{ width: '100%', marginBottom: 10 }}
      />
      <button
        onClick={handleLogin}
        style={{ width: '100%', padding: 10, backgroundColor: '#2d8eff', color: 'white', border: 'none' }}
      >
        Se connecter
      </button>
      <p style={{ marginTop: '1rem' }}>
        Pas encore de compte ?{' '}
        <a href="/signup" style={{ color: '#2d8eff', textDecoration: 'none' }}>
          Inscris-toi
        </a>
      </p>
    </div>
  );
}