import React, { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { AlertTriangle, Clock } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { API } from "@/lib/api";

interface ProcessingStateProps {
  processingId: string;
  onCancel: () => void;
  onComplete: (torrent: any) => void;
}

const ProcessingState: React.FC<ProcessingStateProps> = ({
  processingId,
  onCancel,
  onComplete,
}) => {
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState("Initializing...");
  const [error, setError] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string>("Processing...");
  const [estimatedTime, setEstimatedTime] = useState<string>("Calculating...");

  const { data, isError, error: queryError } = useQuery({
    queryKey: [`/api/processing/${processingId}`],
    refetchInterval: 2000,
  });

  useEffect(() => {
    if (data) {
      setProgress(data.progress || 0);
      
      switch (data.status) {
        case "queued":
          setStatus("Waiting in queue...");
          setEstimatedTime("Waiting to start...");
          break;
        case "downloading":
          setStatus("Downloading metadata...");
          if (data.progress < 25) {
            setEstimatedTime("~60 seconds");
          } else if (data.progress < 50) {
            setEstimatedTime("~45 seconds");
          } else if (data.progress < 75) {
            setEstimatedTime("~30 seconds");
          } else {
            setEstimatedTime("~15 seconds");
          }
          if (data.torrent?.name) {
            setFileName(data.torrent.name);
          }
          break;
        case "processing":
          setStatus("Creating zip file...");
          setEstimatedTime("Almost done...");
          if (data.torrent?.name) {
            setFileName(`${data.torrent.name}.zip`);
          }
          break;
      }
    }
  }, [data, onComplete]);

  // Set up polling for status updates
  useEffect(() => {
    const poller = API.createStatusPoller(processingId, (data) => {
      if (data.progress !== undefined) {
        setProgress(data.progress);
      }
      
      if (data.status === "downloading") {
        const progressText = `Downloading: ${data.progress}%`;
        setStatus(progressText);
      } else if (data.status === "processing") {
        setStatus("Creating zip file...");
      }
      
      if (data.status === "completed" && data.torrent) {
        onComplete(data.torrent);
      } else if (data.status === "error") {
        setError(data.error || "An unknown error occurred");
      }
    });
    
    return () => {
      poller.stop();
    };
  }, [processingId, onComplete]);

  if (isError || error) {
    return (
      <Card className="p-6 mb-8">
        <CardContent className="p-0">
          <div className="flex items-center text-red-500 mb-4">
            <AlertTriangle className="h-6 w-6 mr-2" />
            <h3 className="text-lg font-medium">Processing Error</h3>
          </div>
          
          <p className="text-gray-600 mb-4">
            {error || (queryError instanceof Error ? queryError.message : "An unknown error occurred")}
          </p>
          
          <Button variant="destructive" onClick={onCancel} className="w-full">
            Return to Upload
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="p-6 mb-8">
      <CardContent className="p-0">
        <h3 className="text-lg font-medium mb-4">Processing Magnet Link</h3>
        
        <div className="mb-4">
          <div className="flex justify-between text-sm mb-1">
            <span>Progress</span>
            <span>{progress}%</span>
          </div>
          <Progress value={progress} className="h-2.5" />
        </div>
        
        <div className="border-t border-gray-200 pt-4">
          <div className="text-sm mb-4">
            <div className="flex justify-between py-1">
              <span className="text-gray-600">File name:</span>
              <span className="font-medium">{fileName}</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-gray-600">Status:</span>
              <span className="font-medium text-green-600">{status}</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-gray-600">Estimated time:</span>
              <span className="font-medium">{estimatedTime}</span>
            </div>
          </div>
        </div>
        
        <Button 
          variant="destructive"
          className="w-full mt-2"
          onClick={onCancel}
        >
          Cancel Processing
        </Button>
      </CardContent>
    </Card>
  );
};

export default ProcessingState;
