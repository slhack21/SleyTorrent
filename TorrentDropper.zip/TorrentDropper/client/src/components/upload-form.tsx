import React, { useState, useRef } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { DownloadIcon, Upload, Magnet, File, Clipboard } from "lucide-react";
import { API } from "@/lib/api";
import DownloadsList from "./downloads-list";

const magnetLinkSchema = z.object({
  magnetLink: z.string().startsWith("magnet:?xt=urn:btih:", {
    message: "Invalid magnet link format. Must start with 'magnet:?xt=urn:btih:'",
  }),
  includeMetadata: z.boolean().default(true),
  optimizeSize: z.boolean().default(true),
});

type MagnetLinkFormValues = z.infer<typeof magnetLinkSchema>;

interface UploadFormProps {
  onSubmit: (data: MagnetLinkFormValues) => void;
}

const UploadForm: React.FC<UploadFormProps> = ({ onSubmit }) => {
  const [activeTab, setActiveTab] = useState<string>("upload");
  const [uploadOption, setUploadOption] = useState<string>("magnetLink");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const form = useForm<MagnetLinkFormValues>({
    resolver: zodResolver(magnetLinkSchema),
    defaultValues: {
      magnetLink: "",
      includeMetadata: true,
      optimizeSize: true,
    },
  });

  const handleOptionSelect = (option: string) => {
    setUploadOption(option);
  };

  const handlePasteMagnetLink = async () => {
    try {
      const text = await navigator.clipboard.readText();
      form.setValue("magnetLink", text, { shouldValidate: true });
    } catch (err) {
      toast({
        title: "Clipboard Error",
        description: "Could not read from clipboard. Make sure you've granted permission.",
        variant: "destructive",
      });
    }
  };

  const triggerFileInput = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleTorrentSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files.length > 0) {
      const file = event.target.files[0];
      toast({
        title: "Torrent File Upload",
        description: "Torrent file upload is not implemented in this version.",
      });
    }
  };

  const handleTorrentDrop = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    event.stopPropagation();

    if (event.dataTransfer.files && event.dataTransfer.files.length > 0) {
      toast({
        title: "Torrent File Upload",
        description: "Torrent file upload is not implemented in this version.",
      });
    }
  };

  const handleDragOver = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    event.stopPropagation();
    event.currentTarget.classList.add("border-primary", "bg-blue-50");
  };

  const handleDragLeave = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    event.stopPropagation();
    event.currentTarget.classList.remove("border-primary", "bg-blue-50");
  };

  return (
    <Card className="overflow-hidden mb-8">
      <Tabs defaultValue="upload" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="w-full rounded-none grid grid-cols-2">
          <TabsTrigger value="upload" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
            <Upload className="mr-2 h-4 w-4" /> Upload
          </TabsTrigger>
          <TabsTrigger value="downloads" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
            <DownloadIcon className="mr-2 h-4 w-4" /> Downloads
          </TabsTrigger>
        </TabsList>

        <TabsContent value="upload" className="p-6">
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <Button
              type="button"
              variant={uploadOption === "magnetLink" ? "default" : "outline"}
              className="justify-center py-6 md:w-1/2"
              onClick={() => handleOptionSelect("magnetLink")}
            >
              <Magnet className="mr-2 h-4 w-4" /> Magnet Link
            </Button>
            <Button
              type="button"
              variant={uploadOption === "torrentFile" ? "default" : "outline"}
              className="justify-center py-6 md:w-1/2"
              onClick={() => handleOptionSelect("torrentFile")}
            >
              <File className="mr-2 h-4 w-4" /> Torrent File
            </Button>
          </div>

          {uploadOption === "magnetLink" ? (
            <form
              onSubmit={form.handleSubmit(onSubmit)}
              className="space-y-6"
            >
              <div>
                <Label htmlFor="magnetLink" className="block text-sm font-medium mb-2">
                  Paste Magnet Link
                </Label>
                <div className="flex">
                  <Input
                    id="magnetLink"
                    placeholder="magnet:?xt=urn:btih:..."
                    className="rounded-r-none"
                    {...form.register("magnetLink")}
                  />
                  <Button
                    type="button"
                    variant="outline"
                    className="rounded-l-none"
                    onClick={handlePasteMagnetLink}
                  >
                    <Clipboard className="h-4 w-4" />
                  </Button>
                </div>
                {form.formState.errors.magnetLink && (
                  <p className="text-red-500 text-xs mt-1">
                    {form.formState.errors.magnetLink.message}
                  </p>
                )}
                <p className="text-xs text-gray-500 mt-1">
                  Valid magnet links start with "magnet:?xt=urn:btih:"
                </p>
              </div>

              <div className="border-t border-gray-200 pt-6">
                <h3 className="text-lg font-medium mb-4">Processing Options</h3>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <Checkbox
                      id="includeMetadata"
                      checked={form.watch("includeMetadata")}
                      onCheckedChange={(checked) =>
                        form.setValue("includeMetadata", checked === true)
                      }
                    />
                    <div>
                      <Label htmlFor="includeMetadata" className="font-medium">
                        Include Metadata
                      </Label>
                      <p className="text-gray-500 text-sm">
                        Add metadata information to the zipped file
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <Checkbox
                      id="optimizeSize"
                      checked={form.watch("optimizeSize")}
                      onCheckedChange={(checked) =>
                        form.setValue("optimizeSize", checked === true)
                      }
                    />
                    <div>
                      <Label htmlFor="optimizeSize" className="font-medium">
                        Optimize Size
                      </Label>
                      <p className="text-gray-500 text-sm">
                        Compress the resulting zip file
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <Button
                type="submit"
                className="w-full py-6"
                disabled={!form.formState.isValid || form.formState.isSubmitting}
              >
                <File className="mr-2 h-4 w-4" /> Process Magnet Link
              </Button>
            </form>
          ) : (
            <div>
              <div
                className="border-2 border-dashed border-gray-300 rounded-md p-6 text-center"
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleTorrentDrop}
              >
                <input
                  type="file"
                  id="torrent-file"
                  accept=".torrent"
                  className="hidden"
                  ref={fileInputRef}
                  onChange={handleTorrentSelect}
                />
                <File className="h-16 w-16 text-gray-400 mx-auto mb-3" />
                <p className="text-gray-700 mb-2">
                  Drag and drop your torrent file here
                </p>
                <p className="text-gray-500 text-sm mb-4">or</p>
                <Button type="button" onClick={triggerFileInput}>
                  Browse Files
                </Button>
                <p className="text-xs text-gray-500 mt-4">
                  Accepted file type: .torrent
                </p>
              </div>

              <div className="border-t border-gray-200 pt-6 mt-6">
                <h3 className="text-lg font-medium mb-4">Processing Options</h3>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <Checkbox
                      id="includeMetadata"
                      checked={form.watch("includeMetadata")}
                      onCheckedChange={(checked) =>
                        form.setValue("includeMetadata", checked === true)
                      }
                    />
                    <div>
                      <Label htmlFor="includeMetadata" className="font-medium">
                        Include Metadata
                      </Label>
                      <p className="text-gray-500 text-sm">
                        Add metadata information to the zipped file
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <Checkbox
                      id="optimizeSize"
                      checked={form.watch("optimizeSize")}
                      onCheckedChange={(checked) =>
                        form.setValue("optimizeSize", checked === true)
                      }
                    />
                    <div>
                      <Label htmlFor="optimizeSize" className="font-medium">
                        Optimize Size
                      </Label>
                      <p className="text-gray-500 text-sm">
                        Compress the resulting zip file
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <Button
                type="button"
                className="w-full py-6 mt-6"
                disabled
              >
                <File className="mr-2 h-4 w-4" /> Process Torrent File
              </Button>
            </div>
          )}
        </TabsContent>

        <TabsContent value="downloads">
          <DownloadsList />
        </TabsContent>
      </Tabs>
    </Card>
  );
};

export default UploadForm;
