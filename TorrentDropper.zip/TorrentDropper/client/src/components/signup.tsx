import { useState } from 'react';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { auth } from './firebase';

export default function Signup() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSignup = async () => {
    try {
      await createUserWithEmailAndPassword(auth, email, password);
      alert("Inscription réussie !");
      window.location.href = "/"; // Redirige vers l’accueil
    } catch (error) {
      alert("Erreur lors de l'inscription");
      console.error(error);
    }
  };

  return (
    <div style={{ maxWidth: 400, margin: 'auto', paddingTop: '100px' }}>
      <h2>Inscription</h2>
      <input
        type="email"
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        style={{ width: '100%', marginBottom: 10 }}
      />
      <input
        type="password"
        placeholder="Mot de passe"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        style={{ width: '100%', marginBottom: 10 }}
      />
      <button
        onClick={handleSignup}
        style={{ width: '100%', padding: 10, backgroundColor: '#2d8eff', color: 'white', border: 'none' }}
      >
        S'inscrire
      </button>
      <p style={{ marginTop: '1rem' }}>
        Déjà un compte ?{' '}
        <a href="/login" style={{ color: '#2d8eff', textDecoration: 'none' }}>
          Se connecter
        </a>
      </p>
    </div>
  );
}