import React from "react";
import { AlertTriangle } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface ErrorStateProps {
  message: string;
  details: string;
  onTryAgain: () => void;
  onViewHelp: () => void;
}

const ErrorState: React.FC<ErrorStateProps> = ({
  message,
  details,
  onTryAgain,
  onViewHelp,
}) => {
  return (
    <Card className="p-6 mb-8">
      <CardContent className="p-0 text-center">
        <div className="h-16 w-16 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
          <AlertTriangle className="text-white text-2xl" />
        </div>
        
        <h3 className="text-xl font-medium mb-2">Processing Error</h3>
        <p className="text-gray-600 mb-6">{message}</p>
        
        <div className="bg-red-50 border border-red-100 rounded-lg p-4 mb-6 text-left">
          <h4 className="font-medium text-red-500 mb-2">Error Details:</h4>
          <p className="text-sm text-gray-700">{details}</p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-3">
          <Button 
            variant="default"
            className="flex-1 py-6"
            onClick={onTryAgain}
          >
            Try Again
          </Button>
          <Button 
            variant="outline"
            className="flex-1 py-6"
            onClick={onViewHelp}
          >
            View Help
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default ErrorState;
