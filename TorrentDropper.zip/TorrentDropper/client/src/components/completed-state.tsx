import React from "react";
import { format } from "date-fns";
import { DownloadIcon, Check } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { API } from "@/lib/api";
import type { Torrent } from "@shared/schema";

interface CompletedStateProps {
  torrent: Torrent;
  onReset: () => void;
}

const CompletedState: React.FC<CompletedStateProps> = ({ torrent, onReset }) => {
  const handleDownload = () => {
    window.location.href = API.getDownloadUrl(torrent.id);
  };

  return (
    <Card className="p-6 mb-8">
      <CardContent className="p-0 text-center">
        <div className="h-16 w-16 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
          <Check className="text-white text-2xl" />
        </div>
        
        <h3 className="text-xl font-medium mb-2">Processing Complete!</h3>
        <p className="text-gray-600 mb-6">
          Your magnet link has been processed and is ready for download.
        </p>
        
        <div className="bg-gray-50 rounded-lg p-4 mb-6 text-left">
          <div className="flex justify-between text-sm py-1">
            <span className="text-gray-600">File name:</span>
            <span className="font-medium">{torrent.name}.zip</span>
          </div>
          <div className="flex justify-between text-sm py-1">
            <span className="text-gray-600">Size:</span>
            <span className="font-medium">{torrent.size}</span>
          </div>
          <div className="flex justify-between text-sm py-1">
            <span className="text-gray-600">Created:</span>
            <span className="font-medium">
              {format(new Date(torrent.createdAt), "MMM d, yyyy h:mm a")}
            </span>
          </div>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-3">
          <Button
            variant="default"
            className="flex-1 py-6 bg-green-600 hover:bg-green-700"
            onClick={handleDownload}
          >
            <DownloadIcon className="mr-2 h-4 w-4" /> Download Now
          </Button>
          <Button
            variant="outline"
            className="flex-1 py-6"
            onClick={onReset}
          >
            Process Another
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default CompletedState;
