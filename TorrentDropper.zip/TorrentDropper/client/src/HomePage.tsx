import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { auth } from '../firebase';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";

const HomePage: React.FC = () => {
  const [user, setUser] = useState<any>(null);
  const [magnetLink, setMagnetLink] = useState('');
  const [loading, setLoading] = useState(false);
  const [torrentStatus, setTorrentStatus] = useState<any>(null);
  const [downloadedTorrents, setDownloadedTorrents] = useState<any[]>([]);
  const navigate = useNavigate();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
    });

    // Fetch user's downloaded torrents if authenticated
    if (user) {
      fetchDownloadedTorrents();
    }

    return () => unsubscribe();
  }, [user]);

  const fetchDownloadedTorrents = async () => {
    try {
      const response = await fetch('/api/torrents');
      const torrents = await response.json();
      setDownloadedTorrents(torrents);
    } catch (error) {
      console.error('Failed to fetch torrents:', error);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      navigate('/login');
    } catch (error) {
      console.error('Failed to log out:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const response = await fetch('/api/magnet', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ magnetLink, includeMetadata: true, optimizeSize: false }),
      });
      
      const data = await response.json();
      
      if (response.ok) {
        setTorrentStatus({
          id: data.processingId,
          status: 'processing',
          progress: 0
        });
        
        // Start polling for status updates
        pollTorrentStatus(data.processingId);
      } else {
        throw new Error(data.message || 'Failed to process magnet link');
      }
    } catch (error: any) {
      console.error('Error submitting magnet link:', error);
      setTorrentStatus({
        status: 'error',
        error: error.message
      });
    } finally {
      setLoading(false);
    }
  };

  const pollTorrentStatus = (processingId: string) => {
    const intervalId = setInterval(async () => {
      try {
        const response = await fetch(`/api/processing/${processingId}`);
        const data = await response.json();
        
        setTorrentStatus({
          id: processingId,
          status: data.status,
          progress: data.progress,
          torrent: data.torrent,
          error: data.error
        });
        
        if (data.status === 'completed' || data.status === 'error') {
          clearInterval(intervalId);
          
          if (data.status === 'completed') {
            // Refresh the list of downloaded torrents
            fetchDownloadedTorrents();
          }
        }
      } catch (error) {
        console.error('Error polling torrent status:', error);
        setTorrentStatus({
          id: processingId,
          status: 'error',
          error: 'Failed to get status update'
        });
        clearInterval(intervalId);
      }
    }, 2000);
  };

  const handleDownload = (torrentId: number) => {
    window.location.href = `/api/download/${torrentId}`;
  };

  return (
    <div className="container mx-auto p-4 max-w-4xl">
      <header className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">TorrentDropper</h1>
        <div>
          {user ? (
            <div className="flex items-center gap-4">
              <span>Hello, {user.displayName || user.email}</span>
              <Button variant="outline" onClick={handleLogout}>Logout</Button>
            </div>
          ) : (
            <div className="flex gap-2">
              <Button onClick={() => navigate('/login')}>Login</Button>
              <Button variant="outline" onClick={() => navigate('/signup')}>Sign Up</Button>
            </div>
          )}
        </div>
      </header>

      <Tabs defaultValue="upload" className="mb-8">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="upload">Upload Magnet Link</TabsTrigger>
          <TabsTrigger value="downloads">My Downloads</TabsTrigger>
        </TabsList>
        
        <TabsContent value="upload">
          <Card>
            <CardHeader>
              <CardTitle>Upload Magnet Link</CardTitle>
              <CardDescription>
                Paste a magnet link to download and zip the torrent files
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="magnetLink">Magnet Link</Label>
                  <Input
                    id="magnetLink"
                    placeholder="magnet:?xt=urn:btih:..."
                    value={magnetLink}
                    onChange={(e) => setMagnetLink(e.target.value)}
                    required
                  />
                </div>
                <Button 
                  type="submit" 
                  className="w-full" 
                  disabled={loading}
                >
                  {loading ? 'Processing...' : 'Process Magnet Link'}
                </Button>
              </form>
              
              {torrentStatus && (
                <div className="mt-6 p-4 border rounded-md">
                  <h3 className="font-medium mb-2">
                    {torrentStatus.status === 'processing' && 'Processing Torrent...'}
                    {torrentStatus.status === 'downloading' && 'Downloading Torrent...'}
                    {torrentStatus.status === 'completed' && 'Download Complete!'}
                    {torrentStatus.status === 'error' && 'Error Processing Torrent'}
                  </h3>
                  
                  {(torrentStatus.status === 'processing' || torrentStatus.status === 'downloading') && (
                    <div className="space-y-2">
                      <Progress value={torrentStatus.progress} />
                      <p className="text-sm text-gray-500">{torrentStatus.progress}% complete</p>
                    </div>
                  )}
                  
                  {torrentStatus.status === 'completed' && torrentStatus.torrent && (
                    <div className="space-y-4">
                      <p>Name: {torrentStatus.torrent.name}</p>
                      <p>Size: {torrentStatus.torrent.size}</p>
                      <Button 
                        onClick={() => handleDownload(torrentStatus.torrent.id)}
                        className="w-full"
                      >
                        Download Zip File
                      </Button>
                    </div>
                  )}
                  
                  {torrentStatus.status === 'error' && (
                    <p className="text-red-500">{torrentStatus.error}</p>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="downloads">
          <Card>
            <CardHeader>
              <CardTitle>Your Downloads</CardTitle>
              <CardDescription>
                Access your previously processed torrents
              </CardDescription>
            </CardHeader>
            <CardContent>
              {downloadedTorrents.length === 0 ? (
                <p className="text-center py-8 text-gray-500">
                  You haven't downloaded any torrents yet
                </p>
              ) : (
                <div className="space-y-4">
                  {downloadedTorrents.map((torrent) => (
                    <div 
                      key={torrent.id} 
                      className="p-4 border rounded-md flex justify-between items-center"
                    >
                      <div>
                        <h3 className="font-medium">{torrent.name}</h3>
                        <p className="text-sm text-gray-500">
                          Size: {torrent.size} • Added: {new Date(torrent.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                      <Button onClick={() => handleDownload(torrent.id)}>
                        Download
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default HomePage;