import { apiRequest } from "./queryClient";
import type { Torrent, ProcessingInfo } from "@shared/schema";

export const API = {
  // Process a magnet link
  processMagnetLink: async (
    magnetLink: string,
    options: {
      includeMetadata: boolean;
      optimizeSize: boolean;
    }
  ) => {
    const response = await apiRequest(
      "POST",
      "/api/magnet",
      {
        magnetLink,
        ...options
      }
    );
    return response.json();
  },

  // Get all torrents
  getTorrents: async (): Promise<Torrent[]> => {
    const response = await apiRequest("GET", "/api/torrents");
    return response.json();
  },

  // Get a specific torrent
  getTorrent: async (id: number): Promise<Torrent> => {
    const response = await apiRequest("GET", `/api/torrents/${id}`);
    return response.json();
  },

  // Delete a torrent
  deleteTorrent: async (id: number) => {
    const response = await apiRequest("DELETE", `/api/torrents/${id}`);
    return response.json();
  },

  // Get processing status
  getProcessingStatus: async (id: string): Promise<ProcessingInfo> => {
    const response = await apiRequest("GET", `/api/processing/${id}`);
    return response.json();
  },

  // Get download URL for a torrent
  getDownloadUrl: (id: number) => {
    return `/api/download/${id}`;
  },
  
  // Poll for processing status updates
  createStatusPoller: (processingId: string, onUpdate: (data: any) => void) => {
    const intervalId = setInterval(async () => {
      try {
        const response = await apiRequest("GET", `/api/processing/${processingId}`);
        const data = await response.json();
        onUpdate(data);
        
        // If processing is completed or errored, stop polling
        if (data.status === "completed" || data.status === "error") {
          clearInterval(intervalId);
        }
      } catch (error) {
        console.error('Error polling for updates:', error);
      }
    }, 2000); // Poll every 2 seconds
    
    return {
      stop: () => clearInterval(intervalId)
    };
  }
};
