// client/firebase.ts
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyDxl8g3BvFInfrYWfF9S_9meQ48HFozlm8",
  authDomain: "torrent-de267.firebaseapp.com",
  projectId: "torrent-de267",
  storageBucket: "torrent-de267.appspot.com",
  messagingSenderId: "132795530850",
  appId: "1:132795530850:web:dc06da6380631880061b3b",
  measurementId: "G-4YPKXLQ16T"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);