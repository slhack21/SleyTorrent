import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const torrents = pgTable("torrents", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  hash: text("hash").notNull(),
  magnetLink: text("magnet_link"),
  size: text("size"),
  zipPath: text("zip_path"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  includeMetadata: boolean("include_metadata").default(true),
  optimizeSize: boolean("optimize_size").default(true),
});

export const insertTorrentSchema = createInsertSchema(torrents).pick({
  name: true,
  hash: true,
  magnetLink: true,
  size: true,
  zipPath: true,
  includeMetadata: true,
  optimizeSize: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertTorrent = z.infer<typeof insertTorrentSchema>;
export type Torrent = typeof torrents.$inferSelect;

export const magnetLinkSchema = z.object({
  magnetLink: z.string().startsWith("magnet:?xt=urn:btih:", { 
    message: "Invalid magnet link format. Must start with 'magnet:?xt=urn:btih:'" 
  }),
  includeMetadata: z.boolean().default(true),
  optimizeSize: z.boolean().default(true),
});

export const processingStatus = z.enum([
  "queued", 
  "downloading", 
  "processing", 
  "completed", 
  "error"
]);

export type ProcessingStatus = z.infer<typeof processingStatus>;

export type ProcessingInfo = {
  id: string;
  status: ProcessingStatus;
  progress: number;
  error?: string;
  torrent?: Torrent;
};
